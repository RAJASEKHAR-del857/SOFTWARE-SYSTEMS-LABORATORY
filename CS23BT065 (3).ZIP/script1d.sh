#!/bin/bash
awk ' { 
        if ($2 < 40) { print $1, $2,"F"; }
        else if ($2 >= 85) { print $1, $2, "A"; }
        else if ($2 >= 70 && $2 < 85) { print $1, $2,"B"; }
        else
           { print $1, $2, "C"; }
}' "data.txt"
