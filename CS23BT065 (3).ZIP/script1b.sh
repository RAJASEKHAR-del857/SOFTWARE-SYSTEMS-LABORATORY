#!/bin/bash
awk '{ if ($2  >= 40) print $1, " : ", "pass"; else print $1, " : ", "fail" }' "data.txt"
