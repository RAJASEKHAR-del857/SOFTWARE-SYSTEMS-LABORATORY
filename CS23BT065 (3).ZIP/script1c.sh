#!/bin/bash
awk 'BEGIN {count=0; sum=0}
{
  if (tolower(substr($1,1,1)) ~ /[aeiou]/ && $2 > 50) {  
   print $1, $2;
   count++;
    sum += $2;
}
}
 END {
if (count > 0)

  print "Average is : ", sum/count;
else
     print "No entries matched the criteria."
}' "data.txt"
