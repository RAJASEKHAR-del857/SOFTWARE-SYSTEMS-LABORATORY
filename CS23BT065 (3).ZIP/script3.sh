#!/bin/bash
if [ $# -ne 1 ]; then
echo " provide exactly one arguement"
exit 1
fi
number=$1

if [[ ! "$number" =~ ^[a-zA-Z_] ]]; then
echo " variable name should start with a letter or underscore (_)"
exit 1
fi

if [[ "$number" =~ [^a-zA-Z0-9_] ]]; then
  echo "Error: Variable name can only contain letters, numbers, and underscores (_)" 
  exit 1
fi


if [[ "$number" =~ [[:space:]] ]]; then
  echo "Error: Variable name cannot contain spaces" 
  exit 1
fi

if [[ "$number" =~ ^[a-zA-Z_][a-zA-Z0-9_]*$ ]]; then
  echo "Valid variable name"
else
  echo "Invalid variable name" 
  exit 1
fi
