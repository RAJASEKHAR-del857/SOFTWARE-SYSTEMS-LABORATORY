#include <stdio.h>
#include <stdlib.h>


void calculate(double num1, double num2, char operator) {
    switch (operator) {
        case '+':
            printf("Result: %.2f\n", num1 + num2);
            break;
        case '-':
            printf("Result: %.2f\n", num1 - num2);
            break;
        case '*':
            printf("Result: %.2f\n", num1 * num2);
            break;
        case '/':
            if (num2 == 0) {
                printf("Error: Division by zero is not possible.\n");
            } else {
                printf("Result: %.2f\n", num1 / num2);
            }
            break;
        default:
            printf("Error: Invalid operator. Use +, -, *, or /.\n");
    }
}

int main() {
    double num1, num2;
    char operator;

    printf("Enter the first number: ");
    if (scanf("%lf", &num1) != 1) {
        printf("Error: Invalid number.\n");
        return 1;
    }

    printf("Enter the operator (+, -, *, /): ");
    scanf(" %c", &operator);

    printf("Enter the second number: ");
    if (scanf("%lf", &num2) != 1) {
        printf("Error: Invalid number.\n");
        return 1;
    }

    calculate(num1, num2, operator);

    return 0;
}

