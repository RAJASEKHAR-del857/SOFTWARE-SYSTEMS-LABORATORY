#!/bin/bash
awk '{ print $1 " - " $3 }' "data.txt"

