#!/bin/bash
sed -i '5,10s/"make"/"makefile"/' "data1.txt"
cat "data1.txt"
