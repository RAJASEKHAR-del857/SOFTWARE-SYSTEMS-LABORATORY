#!/bin/bash
awk '{
      if($2 > 90)  { print $1, $2, "EXCELLENT" ;}
       else if ($2 <= 70 && $2 >50) {
       $2 += 5;
        print $1, $2 ;}
       else 
             { print $1, $2 ;}
}' "data.txt"
