#!/ bin/bash
word=Linux
anotherword=MacOS
sed -i "/$word/d; /$anotherword/d" data1.txt
cat data1.txt
