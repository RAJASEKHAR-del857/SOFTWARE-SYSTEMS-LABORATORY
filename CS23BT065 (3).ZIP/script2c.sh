#!/bin/bash
sed -n '/compilation/p' "data1.txt"
