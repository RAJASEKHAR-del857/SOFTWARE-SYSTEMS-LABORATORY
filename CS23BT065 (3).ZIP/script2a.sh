#!/bin/bash
word="start of file"
sed -i "1s/^/$word\n/" "data1.txt"
cat "data1.txt"
