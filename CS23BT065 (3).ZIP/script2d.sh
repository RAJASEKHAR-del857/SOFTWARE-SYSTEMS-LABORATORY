 #!/bin/bash
word="Makefiles are essential for compilation"
line="Linux and MacOS"
sed -i "/$line/a $word"  "data1.txt"
cat data1.txt
