
#!bin/bash
if [ "$#" -lt 2 ]; then
echo "provide atleast 2 arguements"
exit 1
fi
k=$1
if ! [[ $k =~ ^[0-9]+$ ]] || [ "$k" -le 0 ]; then
echo " k should be a positive integer "
exit 1
fi
numbers=("${@:2}")
if [ "${#numbers[@]}" -lt "$k" ]; then
echo " ERROR: not enough numbers "
exit 1
fi
sorted_num=($(for num in "${numbers[@]}"; do echo $num; done | sort -nr))
kth_largest=${sorted_num[$((k-1))]}
echo " the $k-th largest number is : $kth_largest "

