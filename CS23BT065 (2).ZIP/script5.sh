#!/bin/bash
if [ $# -ne 3 ]; then
echo " provide exactly 3 arguments "
exit 1
fi
dir="$1"
if [ ! -d "$dir" ]; then
echo " enter name of existing directory"
exit 1
fi
prefix="$2"
subdir="$3"
if [ "$subdir" = "true" ]; then
echo "searching in the subdirectories "
files=$(find "$dir" -type f -name "${prefix}*")
elif [ "$subdir" = "false" ]; then
echo "not searching in the subdirectories"
    files=$(find "$dir" -maxdepth 1 -type f -name "${prefix}*")
else
    echo "Error: The third argument must be either 'true' or 'false'."
    exit 1
fi
if [ -z "$files" ]; then
    echo "No files found with prefix '$prefix' in the directory '$directory'."
    exit 1
else
    echo "Files found with prefix '$prefix':"
    echo "$files"
fi


