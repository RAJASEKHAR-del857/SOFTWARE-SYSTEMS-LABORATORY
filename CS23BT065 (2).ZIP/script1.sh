#!/bin/bash
if [ $# -eq 0 ]; then
echo " enter arguments "
exit 1
fi
for arg in "$@"; do
    if ! [[ $arg =~ ^-?[0-9]+([.][0-9]+)?$ ]]; then
             echo " ERROR : invalid number found  '$arg'. "
                 exit 1
        fi
    done
sorted_numbers=($(for i in "$@"; do echo $i; done | sort -n))
echo " sorted list :"
for num in "${sorted_numbers[@]}"; do
echo " $num "
done

echo " minimum value :"
min=${sorted_numbers[0]}
echo "$min"
count=$#
last=$(($count - 1))
echo " maximum value :"
max=${sorted_numbers[$last]}
echo " $max"
sum=0
for num in "$@"; do
sum=$(awk "BEGIN {print $sum + $num}")
done

avg=$( awk "BEGIN {print $sum / $count}") 
echo " the avg is : $avg. "

echo " no of unq elements are :"
echo "${sorted_numbers[@]}" | tr ' ' '\n' | uniq | wc -l

echo " no of duplicates are :"
echo "${sorted_numbers[@]}" | tr ' ' '\n' | uniq -d | wc -l




