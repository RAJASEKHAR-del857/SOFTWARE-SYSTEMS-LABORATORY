#!/bin/bash
if [ $# -ne 1 ]; then
echo -e " provide exactly one arguement \n"
exit 1
fi
directory=$1
if [ ! -d $directory ]; then
echo "enter name of the existing directory "
exit 1
fi
echo "Top 5 Largest files in the directory $directory are:  "

find "$directory" -type f -exec ls -lhS {} + | sort -rh -k 5 | head -n 5 | while read -r line; do

    file_path=$(echo "$line" | awk '{print $9}')
    file_size=$(echo "$line" | awk '{print $5}')
    file_owner=$(stat -c '%U' "$file_path")
    file_mod_date=$(stat -c '%y' "$file_path")


    echo "File: $file_path"
    echo "Size: $file_size"
    echo "Owner: $file_owner"
    echo "Last Modified: $file_mod_date"

done


