#!bin/bash
if [ $# -ne 2 ]; then
echo " provide exactly two arguments"
exit 1
fi
temp=$1
if [ "$2" = "C" ]; then
fh=$(awk " BEGIN { print ($temp * (9/5) + 32) }")

echo " $temp Degree Celcius is $fh Fahrenheit"
elif [ "$2" = "F" ]; then
ch=$(awk "BEGIN { print (($temp - 32) * (5/9)) }")
echo " $temp Fahrenheit is $ch Degree Celcius"

else
echo " invalid input use C for celcius and F for farenheit "
exit 1
fi
