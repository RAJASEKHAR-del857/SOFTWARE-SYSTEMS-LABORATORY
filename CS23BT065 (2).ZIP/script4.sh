#!bin/bash
if [ $# -ne 3 ]; then
echo " exactly provide three arguments "
exit 1
fi
sen="$1"
old="$2"
new="$3"

echo "Original Sentence: $sen"
echo "Old Word: $old"
echo "New Word: $new"

modi=$(echo "$sen" | sed "s/$old/$new/")
echo "Modified Sentence : $modi "
