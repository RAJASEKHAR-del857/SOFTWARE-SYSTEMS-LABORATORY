const timeDisplay = document.getElementById("time-display");
const startStopBtn = document.getElementById("start-stop-btn");
const resetBtn = document.getElementById("reset-btn");

let timer = null;
let running = false;
let startTime = 0;
let elapsedTime = 0;


function formatTime(milliseconds) {
  const hours = String(Math.floor(milliseconds / 3600000)).padStart(2, "0");
  const minutes = String(Math.floor((milliseconds % 3600000) / 60000)).padStart(2, "0");
  const seconds = String(Math.floor((milliseconds % 60000) / 1000)).padStart(2, "0");
  const ms = String(milliseconds % 1000).padStart(3, "0").slice(0, 2);
  return `${hours}:${minutes}:${seconds}.${ms}`;
}

// Function to generate a random color
function getRandomColor() {
  return `#${Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0")}`;
}


startStopBtn.addEventListener("click", () => {
  if (running) {
    clearInterval(timer);
    elapsedTime += Date.now() - startTime;
    startStopBtn.textContent = "Start";
  } else {
    startTime = Date.now();
    timer = setInterval(() => {
      const currentTime = elapsedTime + (Date.now() - startTime);
      timeDisplay.textContent = formatTime(currentTime);
      timeDisplay.style.color = getRandomColor();
    }, 10);
    startStopBtn.textContent = "Stop";
  }
  running = !running;
});


resetBtn.addEventListener("click", () => {
  clearInterval(timer);
  running = false;
  elapsedTime = 0;
  timeDisplay.textContent = "00:00:00.00";
  timeDisplay.style.color = "purple";
  startStopBtn.textContent = "Start";
});

