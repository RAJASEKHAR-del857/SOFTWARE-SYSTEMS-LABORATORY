#!/bin/bash

CPU_THRESHOLD=80
MEMORY_THRESHOLD=90

while true; do
    # Debugging: Echo raw data
    echo "DEBUG: Retrieving system stats..."

    # Retrieve CPU usage
    CPU_USAGE=$(top -bn1 | grep "Cpu(s)" | awk '{print $2 + $4}')
    echo "DEBUG: CPU Usage: $CPU_USAGE"

    # Retrieve memory usage
    MEMORY_USAGE=$(free | awk '/Mem/ {printf "%.2f", $3/$2 * 100.0}')
    echo "DEBUG: Memory Usage: $MEMORY_USAGE"

    # Get the current time
    CURRENT_TIME=$(date +"%Y-%m-%d %H:%M:%S")
    echo "DEBUG: Time: $CURRENT_TIME"

    # Check thresholds
    CPU_ALERT=$(echo "$CPU_USAGE > $CPU_THRESHOLD" | bc)
    MEMORY_ALERT=$(echo "$MEMORY_USAGE > $MEMORY_THRESHOLD" | bc)

    # Debugging: Echo alerts
    echo "DEBUG: CPU Alert: $CPU_ALERT"
    echo "DEBUG: Memory Alert: $MEMORY_ALERT"

    if [ "$CPU_ALERT" -eq 1 ]; then
        echo "ALERT: $CURRENT_TIME - High CPU usage detected: $CPU_USAGE%"
    fi

    if [ "$MEMORY_ALERT" -eq 1 ]; then
        echo "ALERT: $CURRENT_TIME - High memory usage detected: $MEMORY_USAGE%"
    fi

    sleep 60
done

