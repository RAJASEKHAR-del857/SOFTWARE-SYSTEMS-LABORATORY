#!bin/bash
echo -e "\nthe user names and loginshells are: "

#first and seventh field will be usernames and loginshell fields

cut -d ':' -f 1,7 /etc/passwd
