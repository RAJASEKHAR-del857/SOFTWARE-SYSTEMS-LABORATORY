#!/bin/bash
ps -aux | grep -n usr
