#!/bin/bash

echo -e " no of lines which contains 'usr'are:\n"

ps -aux | grep -c usr
