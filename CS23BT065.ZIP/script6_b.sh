#!/bin/bash

echo -e "the lines from 3 to 5 from the file 'etc/group' are:\n"

head -n 5 /etc/group | tail -n 3
