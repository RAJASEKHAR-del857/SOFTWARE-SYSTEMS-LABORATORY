#!/bin/bash
echo -e " the last five lines are:\n "

#enter the names of three files of your choice in the last as similar to below command

tail -n 5 result.txt test.txt data.txt
