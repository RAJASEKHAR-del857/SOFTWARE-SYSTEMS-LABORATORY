#!/bin/bash

echo -e "after sorting the lines 4 to 8 are:\n"

sort /etc/group | head -n 8 |tail -n 4
