 #!/bin/bash

cut -d ':' -f 1-7  /etc/passwd

echo -e " \n after sorting by using numericals from the third column :\n"

sort -t ':' -k 3n /etc/passwd


