#!/bin/bash
ps -aux | grep --colour lib
