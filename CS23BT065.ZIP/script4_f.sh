#!/bin/bash
ps -aux | grep -w lib
