#!/bin/bash

# below the dot(.) correponds to current directory

echo -e "the no of files which are of *.txt type are: "

find . -type f -name "*.txt" | wc -l
