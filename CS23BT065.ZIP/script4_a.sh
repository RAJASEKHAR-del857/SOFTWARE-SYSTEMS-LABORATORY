#!/bin/bash

ps -aux > result.txt

# all processes which are active not only related to current userin user-oriented project
# file created by using touch in terminal
 
echo -e "details saved in the file  'result.txt'." 
