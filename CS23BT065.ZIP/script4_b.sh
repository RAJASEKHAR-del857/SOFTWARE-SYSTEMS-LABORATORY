#!/bin/bash
ps -aux | grep -v usr
