#!/bin/bash

# grep matches the files that starts with script
# the files only whose names starts with script

ls | grep '^script'  | head -n 4 | tail -n 3
