#!/bin/bash

# reverse only surnames 
# when second column is considered as surnames
# pipe for multiple commands

cut -d ' ' -f 2 test.txt  | rev

