#!/bin/bash

if [ "$(ls -A)" ]; then
 echo -e "files found and will be sorted according to their size."
else
 echo -e "/n no files found "
exit 1
fi

echo -e " after sorting files  by using their size :"

#in case of similar size sorting will be done alphabetically
 
ls -lhS

