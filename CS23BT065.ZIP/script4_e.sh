#!/bin/bash
ps -aux | grep -v usr | head -n 2
