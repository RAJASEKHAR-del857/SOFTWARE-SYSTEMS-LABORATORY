#!/bin/bash

# when  second column is cosidered as surnames
# pipe for multiple commands
# file created by using touch in the terminal

cut -d ' ' -f 2 test.txt | rev | tail -n 5 > newfile.txt
cat newfile.txt
echo -e "\nreversed surnames stored in the file 'newfile.txt' "
