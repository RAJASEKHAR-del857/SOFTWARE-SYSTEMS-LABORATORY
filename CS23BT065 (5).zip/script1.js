const paragraphs = document.querySelectorAll(".paragraph");
const tooltip = document.getElementById("tooltip");

paragraphs.forEach(paragraph => {
paragraph.addEventListener("mouseover",(event) => {
const length = paragraph.textContent.length;
tooltip.textContent = `Length: ${length} characters`;
tooltip.style.display = "block";
tooltip.style.left = `${event.pageX + 10}px`;
tooltip.style.top = `${event.pageY + 10}px`;
});

paragraph.addEventListener("mousemove", (event) => {
tooltip.style.left = `${event.pageX + 10}px`;
tooltip.style.top = `${event.pageY + 10}px`;
});

paragraph.addEventListener("mouseout", ( ) => {
tooltip.style.display = "none";
});
});

