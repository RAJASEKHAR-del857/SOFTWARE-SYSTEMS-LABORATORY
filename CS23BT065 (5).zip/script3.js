document.getElementById('task-form').addEventListener('submit', function(event) {
    event.preventDefault(); 

    const taskInput = document.getElementById('task-input');
    const taskText = taskInput.value.trim();

    if (taskText === '') {
        alert('Please enter a task');
        return;
    }

    const taskList = document.getElementById('task-list');
    const listItem = document.createElement('li');

    const taskContent = document.createElement('span');
    taskContent.textContent = taskText;

    const removeButton = document.createElement('button');
    removeButton.textContent = 'Remove';
    removeButton.classList.add('remove-btn');
    removeButton.addEventListener('click', () => listItem.remove());

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.addEventListener('change', function() {
        if (this.checked) {
            taskContent.style.textDecoration ='line-through';
        } else {
           taskContent.style.textDecoration = `none`;
        }
    });

    listItem.appendChild(checkbox);
    listItem.appendChild(taskContent);
    listItem.appendChild(removeButton);
    taskList.appendChild(listItem);

    taskInput.value = '';
});
