const passwordInput = document.getElementById('password');
const strengthBar = document.getElementById('strength-bar');
const strengthText = document.getElementById('strength-text');
const submitButton = document.getElementById('submit-btn');

passwordInput.addEventListener('input', () => {
    const password = passwordInput.value;
    let strength = 0;

    if (password.length >= 6) strength++; 
    if (/[A-Z]/.test(password) && /[a-z]/.test(password)) strength++; 
    if (/\d/.test(password)) strength++; 
    if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) strength++; 

    updateStrengthMeter(strength);
});

function updateStrengthMeter(strength) {
 
    switch (strength) {
        case 0:
        case 1:
            strengthBar.style.backgroundColor = 'red';
            strengthText.textContent = 'Weak';
            submitButton.disabled = true;
            submitButton.classList.remove('enabled');
            break;
        case 2:
            strengthBar.style.backgroundColor = 'orange';
            strengthText.textContent = 'Medium';
            submitButton.disabled = true;
            submitButton.classList.remove('enabled');
            break;
        case 3:
        case 4:
            strengthBar.style.backgroundColor = 'green';
            strengthText.textContent = 'Strong';
            submitButton.disabled = false;
            submitButton.classList.add('enabled');
            break;
    }
}
